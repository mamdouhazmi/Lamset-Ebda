import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

type Pair = { before: string; after: string };
type Category = { title: string; pairs: Pair[] };

const CATEGORIES: Category[] = [
  {
    title: 'تنظيف داخلي',
    pairs: Array.from({ length: 7 }, (_, i) => ({
      before: `/B${i + 1}.jpeg`,
      after: `/A${i + 1}.jpeg`,
    })),
  },
  {
    title: 'غسيل خارجي',
    pairs: Array.from({ length: 7 }, (_, i) => ({
      before: `/BO${i + 1}.jpeg`,
      after: `/AO${i + 1}.jpeg`,
    })),
  },
];

// Checks that both images in a pair load successfully; skips broken pairs.
function checkImage(src: string): Promise<boolean> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(true);
    img.onerror = () => resolve(false);
    img.src = src;
  });
}

export default function BeforeAfter() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [activeTab, setActiveTab] = useState(0);
  const [current, setCurrent] = useState(0);
  const [validPairs, setValidPairs] = useState<Pair[][]>([[], []]);
  const [loading, setLoading] = useState(true);

  // Filter each category down to pairs whose before AND after images both exist.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const results = await Promise.all(
        CATEGORIES.map(async (cat) => {
          const checks = await Promise.all(
            cat.pairs.map(async (p) => {
              const [b, a] = await Promise.all([checkImage(p.before), checkImage(p.after)]);
              return b && a ? p : null;
            })
          );
          return checks.filter((p): p is Pair => p !== null);
        })
      );
      if (!cancelled) {
        setValidPairs(results);
        setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Reset the visible pair when switching categories.
  useEffect(() => {
    setCurrent(0);
  }, [activeTab]);

  const pairs = validPairs[activeTab] ?? [];
  const total = pairs.length;
  const activePair = total > 0 ? pairs[Math.min(current, total - 1)] : null;

  const goPrev = () => setCurrent((c) => (c - 1 + total) % total);
  const goNext = () => setCurrent((c) => (c + 1) % total);

  return (
    <section id="before-after" className="section-alt py-20 lg:py-32" ref={ref} data-testid="section-before-after">
      <div className="container mx-auto px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-[var(--color-light)] mb-4">
            <span className="text-gradient">قبل وبعد</span>
          </h2>
          <p className="text-lg md:text-xl text-[var(--color-muted-blue)] max-w-2xl mx-auto">
            شاهد الفرق الذي نصنعه في كل سيارة نعتني بها
          </p>
        </motion.div>

        {/* Category Tabs */}
        <div className="flex justify-center gap-4 mb-12">
          {CATEGORIES.map((cat, index) => (
            <button
              key={index}
              onClick={() => setActiveTab(index)}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                activeTab === index
                  ? 'bg-[#415A77] text-[#E0E1DD]'
                  : 'bg-[#1B263B] border border-[#415A77]/30 text-[#778DA9] hover:text-[#E0E1DD]'
              }`}
              data-testid={`tab-${index}`}
            >
              {cat.title}
            </button>
          ))}
        </div>

        {/* Comparison Display */}
        <div className="max-w-5xl mx-auto">
          {loading ? (
            <div className="w-full aspect-video rounded-2xl bg-[#1B263B] border border-[#415A77]/30 animate-pulse" />
          ) : activePair ? (
            <>
              <motion.div
                key={`${activeTab}-${current}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="relative"
              >
                <ComparisonSlider
                  before={activePair.before}
                  after={activePair.after}
                  title={CATEGORIES[activeTab].title}
                />

                {/* Arrow Navigation */}
                {total > 1 && (
                  <>
                    <button
                      onClick={goPrev}
                      aria-label="السابق"
                      className="absolute top-1/2 -translate-y-1/2 right-3 z-20 w-11 h-11 rounded-full bg-[#0D1B2A]/80 border border-[#415A77]/40 text-[#E0E1DD] flex items-center justify-center hover:bg-[#415A77] transition-colors"
                      data-testid="button-prev"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                    <button
                      onClick={goNext}
                      aria-label="التالي"
                      className="absolute top-1/2 -translate-y-1/2 left-3 z-20 w-11 h-11 rounded-full bg-[#0D1B2A]/80 border border-[#415A77]/40 text-[#E0E1DD] flex items-center justify-center hover:bg-[#415A77] transition-colors"
                      data-testid="button-next"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>
                  </>
                )}
              </motion.div>

              {/* Dot Indicators */}
              {total > 1 && (
                <div className="flex items-center justify-center gap-2 mt-6">
                  {pairs.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrent(i)}
                      aria-label={`الصورة ${i + 1}`}
                      className={`h-2.5 rounded-full transition-all ${
                        i === current ? 'w-8 bg-[#415A77]' : 'w-2.5 bg-[#778DA9]/40 hover:bg-[#778DA9]/70'
                      }`}
                      data-testid={`dot-${i}`}
                    />
                  ))}
                </div>
              )}

              {total > 1 && (
                <p className="text-center text-[#778DA9] mt-3 text-sm" dir="ltr">
                  {current + 1} / {total}
                </p>
              )}
            </>
          ) : (
            <div className="w-full aspect-video rounded-2xl bg-[#1B263B] border border-[#415A77]/30 flex items-center justify-center">
              <p className="text-[#778DA9] text-lg">لا توجد صور متاحة حالياً</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}function ComparisonSlider({
  before,
  after,
  title,
}: {
  before: string;
  after: string;
  title: string;
}) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);

  const handleMove = (clientX: number, containerRect: DOMRect) => {
    const x = clientX - containerRect.left;
    const percentage = (x / containerRect.width) * 100;
    setSliderPosition(Math.max(0, Math.min(100, percentage)));
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    handleMove(e.clientX, e.currentTarget.getBoundingClientRect());
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    handleMove(e.touches[0].clientX, e.currentTarget.getBoundingClientRect());
  };

  return (
    <div
      className="relative mx-auto rounded-2xl overflow-hidden cursor-col-resize select-none bg-[#1B263B] border border-[#415A77]/30"
      style={{
        width: "min(60vw, 650px)",
        aspectRatio: "3 / 4",
      }}
      onMouseMove={handleMouseMove}
      onMouseDown={() => setIsDragging(true)}
      onMouseUp={() => setIsDragging(false)}
      onMouseLeave={() => setIsDragging(false)}
      onTouchMove={handleTouchMove}
      onTouchStart={() => setIsDragging(true)}
      onTouchEnd={() => setIsDragging(false)}
      data-testid={`comparison-${title}`}
    >
      {/* After Image */}
      <img
        src={after || "/placeholder.svg"}
        alt={`بعد - ${title}`}
        className="absolute inset-0 w-full h-full object-contain bg-[#1B263B]"
        draggable={false}
      />

      {/* Before Image */}
      <div
        className="absolute inset-0 overflow-hidden"
        style={{
          clipPath: `inset(0 ${100 - sliderPosition}% 0 0)`,
        }}
      >
        <img
          src={before || "/placeholder.svg"}
          alt={`قبل - ${title}`}
          className="absolute inset-0 w-full h-full object-contain bg-[#1B263B]"
          draggable={false}
        />
      </div>

      {/* Slider */}
      <div
        className="absolute top-0 bottom-0 w-1 bg-white"
        style={{
          right: `${100 - sliderPosition}%`,
        }}
      >
        <div className="absolute top-1/2 right-1/2 -translate-y-1/2 translate-x-1/2 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center">
          <div className="flex gap-1">
            <div className="w-0.5 h-6 bg-[#0D1B2A]" />
            <div className="w-0.5 h-6 bg-[#0D1B2A]" />
          </div>
        </div>
      </div>

      {/* Labels */}
      <div className="ba-tag absolute top-4 right-4">
        بعد
      </div>

      <div className="ba-tag absolute top-4 left-4">
        قبل
      </div>
    </div>
  );
}